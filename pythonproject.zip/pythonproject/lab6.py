"""
This program enables a user to input short one line notes and have them stored in a file called pynote.txt

"""

import WorkingFile as wf

def run():
    note = input("Please enter a note (enter :d to delete a note or :q to exit):  ")
    if note == ":d":
        try:
            note = wf.remove_note()
            if note is None:
                assert False, "FileNotFoundError should have been raised"
            
            print(f"The following note has been removed: \n\n {note}")
        except FileNotFoundError:
            print("The PyNote.txt file no longer exists")
    elif note == ":q":
        return
    else:    
        wf.save_note(note)
    run()


if __name__ == "__main__":
    assert wf.is_int(5) == True
    assert wf.is_int("five") == False

    print("Welcome to PyNote! \n")
    wf.read_notes()

    run()